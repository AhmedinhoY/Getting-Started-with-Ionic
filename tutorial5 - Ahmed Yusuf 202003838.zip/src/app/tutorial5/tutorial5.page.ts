import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tutorial5',
  templateUrl: './tutorial5.page.html',
  styleUrls: ['./tutorial5.page.scss'],
})
export class Tutorial5Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
